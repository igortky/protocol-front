﻿import React, { useState, useEffect, useRef } from "react";
import { withRouter, useParams } from "react-router-dom";
import { Form, Container } from "./styles";
import { Col, Row } from "shards-react"
import { handleSubmit } from "../../services/service.js";
import { createProtocolo } from "../../services/protocoloService";
import { tokenHandler } from "../../services/tokenService.js";
import protocolBox from "./protocolBox";
import typingBox from "./typingBox";
import logo from "../../images/logo.png";
import download from "../../images/download.svg"
import anexo from "../../images/anexo.svg"
import Unauthorized from "../Unauthorized/unauthorized.js";
import Modal from "../Modal/Modal.jsx"

function FrontPage() {
  const { token } = useParams();
  const [destinatario, setDestinatario] = useState("");
  const [status, setStatus] = useState(true);
  const [temContato, setTemContato] = useState(true);
  const [protocolo, setProtocolo] = useState(createProtocolo());
  const [checado, setChecado] = useState(false);
  const [checkEmail, setCheckEmail] = useState(true);
  const [checkSms, setCheckSms] = useState(false);
  const [placeholder, setPlaceholder] = useState("Digite o email de destino...");
  const [checkWhatsapp, setCheckWhatsapp] = useState(false);
  // MODAL
  const [dropdown, setDropdown] = useState(""); 
  const modalRef = useRef(null);


  const toggleDropdown = () => {
   
    //se clicar no botão, modal aparece
    setDropdown("show");
    document.body.addEventListener("click", closeDropdown);
  }

  const closeDropdown = event => {
    event.stopPropagation(); //impede de executar listeners dos filhos
    const contain = modalRef.current.contains(event.target);
    if (!contain) { //se clicar fora do modal, ele DeSaparece
      console.log("hidden");
      setDropdown("");
      document.body.removeEventListener("click", closeDropdown);
    }
  };

  // useEffect(() => {
  //   tokenHandler(token, setStatus);
  // }, []);

  useEffect(() => {
    if (checado) {
      setPlaceholder("Digite o telefone do Cliente...")
    } else {
      if (checkEmail) {
        setPlaceholder("Digite o email do Cliente...")
      } else if (checkSms) {
        setPlaceholder("Digite o telefone do cliente para envio do SMS...")
      } else if (checkWhatsapp) {
        setPlaceholder("Digite o Whatsapp do cliente...")
      }
    }
  }, [checado]);

  useEffect(() => {
    if (checkEmail) {
      setPlaceholder("Digite o email do Cliente...")
    }
  }, [checkEmail]);

  useEffect(() => {
    if (checkSms) {
      setPlaceholder("Digite o telefone do cliente para envio do SMS...")
    }
  }, [checkSms]);

  useEffect(() => {
    if (checkWhatsapp) {
      setPlaceholder("Digite o Whatsapp do cliente...")
    }
  }, [checkWhatsapp]);

  const handleClick = (handleSubmit, e, destinatario, protocolo,
    createProtocolo, setProtocolo, checado, checkSms, checkEmail, checkWhatsapp) => {
    e.preventDefault();
    setProtocolo(createProtocolo());
    handleSubmit(destinatario, protocolo, checado, checkSms, checkEmail, checkWhatsapp);
  }

  const handleChange = (temContato, setTemContato,
    checado, setChecado, setPlaceholder) => {
    if (!checado) {
      setChecado(true);
      setCheckWhatsapp(false);
      setCheckEmail(false);
      setCheckSms(false);
      setTemContato(!temContato);
      setPlaceholder("Digite o telefone do Cliente...")
    } else {
      setChecado(false);
      setCheckWhatsapp(false);
      setCheckEmail(true);
      setCheckSms(false);
      setTemContato(!temContato);
    }
  }

  const handleCheckEmail = (setCheckEmail, setCheckSms,
    setPlaceholder, setCheckWhatsapp, setChecado) => {
    setCheckEmail(true);
    setCheckWhatsapp(false);
    setCheckSms(false);
    setChecado(false);
    setPlaceholder("Digite o email do Cliente...")
  }

  const handleCheckSms = (setCheckSms, setCheckEmail, setPlaceholder,
    setCheckWhatsapp, setChecado) => {
    setCheckSms(true);
    setCheckWhatsapp(false);
    setCheckEmail(false);
    setChecado(false);
    setPlaceholder("Digite o telefone do cliente para envio do SMS...");
  }

  const handleCheckWhatsapp = (setCheckWhatsapp,
    setCheckEmail, setCheckSms, setPlaceholder, setChecado) => {
    setCheckWhatsapp(true);
    setCheckEmail(false);
    setCheckSms(false);
    setChecado(false);
    setPlaceholder("Digite o Whatsapp do cliente...");
  }

  if (status === true) {
    return (
      <Container>
        <Row>
          <Col>
            <Form>
              <img src={logo} alt="" style={{
                left: "157px", top: "-20px", width: "292px", height: "78px", marginTop: "20px", marginBottom: "30px"
              }} />
              {protocolBox(protocolo)}
              {typingBox(temContato, setDestinatario, checkEmail, setCheckEmail, checkSms, setCheckSms,
                handleCheckEmail, handleCheckSms, setPlaceholder, placeholder, checkWhatsapp, setCheckWhatsapp,
                handleCheckWhatsapp, setTemContato, checado, setChecado, handleChange)}
              <div className="buttons">
               
                {/* <button className="anexos" onClick={toggleDropdown} > <img src={anexo} /> </button>
                <Modal className={dropdown} modalRef={modalRef}/> */}
                <button className="button" onClick={(e) =>
                  handleClick(handleSubmit, e, destinatario, protocolo,
                    createProtocolo, setProtocolo, checado, checkSms, checkEmail, checkWhatsapp)}><span>Enviar</span></button>
              </div>
            </Form>
          </Col>
        </Row>
      </Container>
    )
  } else {
    return (
      <Unauthorized />
    );
  }
}
export default withRouter(FrontPage);