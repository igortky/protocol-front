import React from "react";
import { Row, FormInput, FormCheckbox } from "shards-react"
import textoTopo from "../../images/texto_topo.svg";

export default function protocolBox(protocolo) {
    return (
        <div>
            <p src={textoTopo} className="texto-topo">Número de protocolo:</p>
            <Row>
                <FormInput className="teste" value={protocolo} style={{color: '#007DA2'}} />
            </Row>
        </div>
    );
}